---
name: Autonomous Vision Edge
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2151da'
  primary: '#0037b0'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#3d445a'
  on-tertiary: '#ffffff'
  tertiary-container: '#545c72'
  on-tertiary-container: '#cdd5ef'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b5'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-ui:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system drives the interface for an edge-vision automated retail checkout platform. The brand personality conveys surgical precision, operational dependability, and frictionless speed. It merges the institutional trustworthiness demanded by enterprise B2B retail stakeholders with the instant, intuitive clarity needed by end consumers during unattended physical transactions.

The visual style blends **High-Tech Minimalism** with disciplined **Technical Glassmorphism**:
- Ultra-clean pure white and crisp cool-slate surfaces prevent cognitive fatigue in transactional environments.
- Precise luminous cyan and electric blue accents simulate laser-guided optics, real-time sensor streams, and edge telemetry.
- Subtle frosted backdrops, refined borders, and soft tech glows emphasize physical-to-digital spatial continuity without sacrificing industrial legibility.
- Visual elements favor architectural balance, high-density telemetry readouts, micro-badges, and low-latency interaction feedback.

## Colors

The palette is engineered for high optical clarity and technical authority, leveraging cool slate undertones against clinical whites:

- **Primary (`#1D4ED8`)**: Electric Blue serves as the core operational signal for primary conversion targets, validation states, and high-priority system actions.
- **Secondary (`#06B6D4`)**: Cyber Cyan provides the dynamic energy layer, denoting live edge processing, sensor bounding boxes, hardware telemetry pulses, and directional prompts.
- **Tertiary (`#0F172A`)**: Deep Slate Obsidian acts as the anchor color for structural frames, high-impact technical headers, terminal outputs, and contrast surfaces.
- **Neutral Palette**: Built on slate gradations:
  - Surface Pure: `#FFFFFF`
  - Canvas Substrate: `#F8FAFC`
  - Structural Surface Container: `#F1F5F9`
  - Subtle Dividing Border: `#E2E8F0`
  - Body & Auxiliary Slate: `#64748B`
- **Functional Semantics**:
  - Success / Validated: `#059669` (Vision capture verified)
  - Alert / Review Needed: `#D97706` (Manual verification needed)
  - Critical Stop: `#DC2626` (Weight/sensor discrepancy)

## Typography

The typographic hierarchy establishes clear distinction between machine data and human interaction:

- **Space Grotesk** powers landing page titles, metrics, and section headlines. Its geometric construction reinforces the algorithmic, computational nature of edge-vision checkout.
- **Plus Jakarta Sans** manages primary Korean and English body copy, delivering readability across dense feature breakdowns, case studies, and transactional screens.
- **JetBrains Mono** is reserved for telemetry values, detection latency metrics (e.g., `0.18s LATENCY`), bounding box coordinates, inference engine status, and edge chip specifications.
- **Korean Localization**: Korean copy paired with Plus Jakarta Sans must use `word-break: keep-all` to prevent unnatural line breaks and maintain structural symmetry.

## Layout & Spacing

The design system implements a strict 12-column grid system built on an 8px base rhythm:

- **Desktop (1200px+)**: 12-column fluid grid within a 1280px max-width content container, using a `3rem` section margin and `1.5rem` gutters.
- **Tablet (768px – 1199px)**: 8-column layout with `2rem` margins and `1.25rem` gutters. Dual-pane technical displays collapse into stacked vertical modules.
- **Mobile (< 768px)**: 4-column layout with `1.25rem` margins and `1rem` gutters. Complex interactive live-sensor diagrams stack into horizontally scrollable or swipeable card groups.
- **Vertical Spacing Cadence**:
  - Hero sections and category transitions use `space-3xl` (`6rem`).
  - Related feature blocks and diagram matrices use `space-2xl` (`4rem`).
  - Modular cards within the same tier use `space-lg` (`1.5rem`).

## Elevation & Depth

Visual hierarchy combines light reflection, tonal separation, and targeted luminescent shadows:

- **Level 0 (Floor Canvas)**: Solid `#FFFFFF` or `#F8FAFC` foundation.
- **Level 1 (Substrate Cards)**: Surface `#FFFFFF` bordered by `1px solid #E2E8F0` with subtle ambient depth:
  `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 4px 12px -2px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Active Edge Cards & Floating HUDs)**: Frosted glass effect using `background: rgba(255, 255, 255, 0.82)`, `backdrop-filter: blur(12px)`, bordered by `1px solid rgba(226, 232, 240, 0.8)`, and elevated by:
  `box-shadow: 0 10px 25px -5px rgba(29, 78, 216, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Interactive Telemetry & Focus Items)**: Elevated with cyber cyan optical glow:
  `box-shadow: 0 0 20px 0 rgba(6, 182, 212, 0.18), 0 20px 25px -5px rgba(15, 23, 42, 0.08)`.
- **Dark Inset Module (Vision Sensor Terminal)**: Pure `#0F172A` ground with inner cyan rim lighting `inset 0 1px 0 0 rgba(6, 182, 212, 0.3)`.

## Shapes

The design system uses deliberate radii to balance structural precision with user-facing accessibility:

- **Standard Containers & Cards**: Set to `rounded-lg` (1rem / 16px) to maintain a modern, friendly yet precise consumer-facing aesthetic.
- **Interactive Buttons & Input Fields**: Set to standard `rounded` (0.5rem / 8px) for crisp tactile interaction.
- **Telemetry Chips & Edge Badges**: Fully pill-shaped (`rounded-full` / 9999px) to signal discrete live status flags, sensor identifiers, and real-time validation markers.
- **Bounding Boxes & Scanner Overlays**: 2px stroke width with distinct 4px corner accents (`corner-bracket` styling) to evoke camera viewfinder and AI inference metadata.

## Components

### Buttons
- **Primary Action (Deploy / Scan / Buy)**: Solid `#1D4ED8` fill, `#FFFFFF` text, `0.5rem` radius, subtle top-edge highlight (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`). Hover initiates a transition to `#1E40AF` accompanied by a localized cyan ambient glow (`0 0 16px rgba(6, 182, 212, 0.35)`).
- **Secondary / Technical Outlined**: `#FFFFFF` background, `1px solid #CBD5E1`, text `#0F172A`. Hover brings a border shift to `#1D4ED8` and text shift to `#1D4ED8`.
- **Ghost Action**: Transparent background with `#64748B` typography, transitioning to `#0F172A` on hover with a subtle `#F1F5F9` background fill.

### Edge Status Badges & Chips
- **Live Indicator Badge**: Compact pill with JetBrains Mono typography (`label-mono`), tracking a pulsing status orb. 
  - Standard edge state: Background `rgba(6, 182, 212, 0.1)`, text `#0891B2`, border `1px solid rgba(6, 182, 212, 0.3)`.
  - Processing state: Glowing dot with CSS radar sweep animation.

### Cards & Telemetry Surfaces
- **Feature & Hardware Modules**: Encased in Level 1 or Level 2 glass, featuring an upper-right monospace metric tag (e.g., `ACCURACY 99.98%`). Internal padding spans `space-lg` to `space-xl`.
- **Cart Checkout Item Row**: Crisp white surface containing a thumbnail preview, Korean typography description, real-time edge confidence metric (`99.4% AI Match`), and item cost.

### Form Inputs & Selectors
- Background `#FFFFFF`, border `1px solid #E2E8F0`, interior padding `0.75rem 1rem`, text `#0F172A`. Focused state triggers `1px solid #1D4ED8` along with a ring shadow `0 0 0 3px rgba(6, 182, 212, 0.15)`.

### Checkboxes & Binary Selectors
- Standard `0.375rem` rounded corners. Checked status applies `#1D4ED8` background with an angular white vector check mark.

### Domain-Specific Components
- **Object Detection Reticle**: Translucent cyan box (`rgba(6, 182, 212, 0.08)`) with `1px dashed #06B6D4` boundaries, anchored by solid high-contrast corner reticles and a floating monospace identifier badge.
- **Latency & Throughput Counter**: Dual-color metric module combining large numeric figures in Space Grotesk with secondary units in JetBrains Mono (`ms`, `FPS`, `NPU TOPS`).